C++
make/make run
make run does everything
Time measured is 0 seconds for all inputs
